<?php
require_once '../includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: ../auth/login.php');
    exit;
}

// Get current user data
$user = getCurrentUser();

// Get filter parameters
$status = $_GET['status'] ?? 'all';
$sort = $_GET['sort'] ?? 'newest';

// Build query
$query = "
    SELECT b.*, p.title, p.destination, p.price 
    FROM bookings b 
    JOIN packages p ON b.package_id = p.id 
    WHERE b.user_id = ?
";

if ($status !== 'all') {
    $query .= " AND b.status = ?";
}

$query .= " ORDER BY " . ($sort === 'oldest' ? 'b.created_at ASC' : 'b.created_at DESC');

// Execute query
$conn = getDBConnection();
$stmt = $conn->prepare($query);

if ($status !== 'all') {
    $stmt->execute([$_SESSION['user_id'], $status]);
} else {
    $stmt->execute([$_SESSION['user_id']]);
}

$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - WonderEase Travel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="user-info">
                <h3>Welcome, <?php echo htmlspecialchars($user['name']); ?></h3>
                <p><?php echo htmlspecialchars($user['email']); ?></p>
            </div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="bookings.php" class="active">My Bookings</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="support.php">Support</a></li>
                    <li><a href="packages.php">Packages</a></li>
                    <li><a href="../auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <header>
                <h1>My Bookings</h1>
                
                <!-- Filters -->
                <div class="filters">
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label for="status">Status:</label>
                            <select name="status" id="status" onchange="this.form.submit()">
                                <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>All</option>
                                <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="confirmed" <?php echo $status === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                <option value="cancelled" <?php echo $status === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="sort">Sort by:</label>
                            <select name="sort" id="sort" onchange="this.form.submit()">
                                <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest First</option>
                                <option value="oldest" <?php echo $sort === 'oldest' ? 'selected' : ''; ?>>Oldest First</option>
                            </select>
                        </div>
                    </form>
                </div>
            </header>

            <section class="bookings">
                <?php if (empty($bookings)): ?>
                    <p>No bookings found. <a href="../packages.php">Browse packages</a></p>
                <?php else: ?>
                    <div class="booking-list">
                        <?php foreach ($bookings as $booking): ?>
                            <div class="booking-card">
                                <h3><?php echo htmlspecialchars($booking['title']); ?></h3>
                                <p class="destination"><?php echo htmlspecialchars($booking['destination']); ?></p>
                                <div class="booking-details">
                                    <p><strong>Booking Date:</strong> <?php echo date('M d, Y', strtotime($booking['booking_date'])); ?></p>
                                    <p><strong>Travelers:</strong> <?php echo $booking['travelers']; ?></p>
                                    <p><strong>Total Price:</strong> $<?php echo number_format($booking['total_price'], 2); ?></p>
                                    <p><strong>Status:</strong> <span class="status-<?php echo $booking['status']; ?>"><?php echo ucfirst($booking['status']); ?></span></p>
                                    <p><strong>Booked on:</strong> <?php echo date('M d, Y', strtotime($booking['created_at'])); ?></p>
                                </div>
                                <?php if ($booking['status'] === 'pending'): ?>
                                    <div class="booking-actions">
                                        <a href="cancel_booking.php?id=<?php echo $booking['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel this booking?')">Cancel Booking</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </div>
</body>
</html> 