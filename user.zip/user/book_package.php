<?php
require_once '../includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: auth/login.php');
    exit;
}

// Check if package ID is provided
if (!isset($_GET['id'])) {
    header('Location: packages.php');
    exit;
}

$package_id = (int)$_GET['id'];

// Get package details
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT * FROM packages WHERE id = ?");
$stmt->execute([$package_id]);
$package = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$package) {
    header('Location: packages.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_date = $_POST['booking_date'] ?? '';
    $travelers = (int)($_POST['travelers'] ?? 0);
    
    // Validate input
    if (empty($booking_date)) {
        $error = 'Please select a booking date';
    } elseif ($travelers < 1) {
        $error = 'Please enter a valid number of travelers';
    } else {
        // Calculate total price
        $total_price = $package['price'] * $travelers;
        
        // Create booking
        try {
            $stmt = $conn->prepare("
                INSERT INTO bookings (user_id, package_id, booking_date, travelers, total_price)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $package_id,
                $booking_date,
                $travelers,
                $total_price
            ]);
            
            // Create notification
            $stmt = $conn->prepare("
                INSERT INTO notifications (user_id, message)
                VALUES (?, ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                "Your booking for {$package['title']} has been confirmed!"
            ]);
            
            $success = 'Booking successful!';
            // Redirect to dashboard after 2 seconds
            header("refresh:1;url=../user/dashboard.php");
        } catch (PDOException $e) {
            $error = 'Booking failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Package - WonderEase Travel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="booking-form">
            <h2>Book <?php echo htmlspecialchars($package['title']); ?></h2>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <div class="package-summary">
                <h3>Package Details</h3>
                <p><strong>Destination:</strong> <?php echo htmlspecialchars($package['destination']); ?></p>
                <p><strong>Duration:</strong> <?php echo $package['duration']; ?> days</p>
                <p><strong>Price per person:</strong> $<?php echo number_format($package['price'], 2); ?></p>
            </div>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="booking_date">Select Date</label>
                    <input type="date" id="booking_date" name="booking_date" 
                           min="<?php echo date('Y-m-d'); ?>" 
                           value="<?php echo htmlspecialchars($_POST['booking_date'] ?? ''); ?>" 
                           required>
                </div>
                
                <div class="form-group">
                    <label for="travelers">Number of Travelers</label>
                    <input type="number" id="travelers" name="travelers" 
                           min="1" max="10" 
                           value="<?php echo htmlspecialchars($_POST['travelers'] ?? '1'); ?>" 
                           required>
                </div>
                
                <div class="form-group">
                    <label>Total Price</label>
                    <p class="total-price" id="total_price">$<?php echo number_format($package['price'], 2); ?></p>
                </div>
                
                <button type="submit" class="btn btn-primary">Confirm Booking</button>
                <a href="packages.php" class="btn">Cancel</a>
            </form>
        </div>
    </div>

    <script>
        // Calculate total price based on number of travelers
        document.getElementById('travelers').addEventListener('input', function() {
            const price = <?php echo $package['price']; ?>;
            const travelers = this.value;
            const total = price * travelers;
            document.getElementById('total_price').textContent = '$' + total.toFixed(2);
        });
    </script>
</body>
</html> 