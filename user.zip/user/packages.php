<?php
require_once '../includes/auth.php';

// Get all packages
$conn = getDBConnection();
$stmt = $conn->query("SELECT * FROM packages ORDER BY featured DESC, created_at DESC");
$packages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get current user data
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Packages - WonderEase Travel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
             <div class="user-info">
                <h3>Welcome, <?php echo htmlspecialchars($user['name']); ?></h3>
                <p><?php echo htmlspecialchars($user['email']); ?></p>
            </div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="bookings.php">My Bookings</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="support.php">Support</a></li>
                    <li><a href="packages.php" class="active">Packages</a></li>
                    <li><a href="../auth/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <header>
                <h1>Travel Packages</h1>
            </header>

            <div class="package-grid">
                <?php foreach ($packages as $package): ?>
                    <div class="package-card">
                        <?php if ($package['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($package['image_url']); ?>" alt="<?php echo htmlspecialchars($package['title']); ?>">
                        <?php endif; ?>
                        <div class="package-card-content">
                            <h2><?php echo htmlspecialchars($package['title']); ?></h2>
                            <p class="destination"><?php echo htmlspecialchars($package['destination']); ?></p>
                            <p class="description"><?php echo htmlspecialchars($package['description']); ?></p>
                            <div class="package-details">
                                <p><strong>Duration:</strong> <?php echo $package['duration']; ?> days</p>
                                <p class="package-price">$<?php echo number_format($package['price'], 2); ?></p>
                            </div>
                            <?php if (isLoggedIn()): ?>
                                <a href="book_package.php?id=<?php echo $package['id']; ?>" class="btn btn-primary">Book Now</a>
                            <?php else: ?>
                                <a href="auth/login.php" class="btn btn-primary">Login to Book</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html>